﻿namespace Demo.Data.Enum
{
    public enum MoveiCategory
    {
        Action = 1,
        Comedy,
        Drama,
        Documentary,
        Horror,
        Cartoon
    }
}
