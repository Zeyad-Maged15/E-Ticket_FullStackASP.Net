﻿using Demo.Models;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Demo.Models
{
    public class Actor
    {
        [Key]
        public int Id { get; set; }
        [DisplayName("Profile Picture")]
        public string? ProfilePicUrl { get; set; }
        [DisplayName("Name")]
        public string? FullName { get; set;}
        [DisplayName("Biography")]
        public string? Bio { get; set;}

        public List<Movie_Actor> Movies_Actors { get; set; }

    }
}
