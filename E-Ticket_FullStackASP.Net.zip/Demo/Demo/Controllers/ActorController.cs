﻿using Demo.Data;
using Demo.Models;
using Microsoft.AspNetCore.Mvc;

namespace Demo.Controllers
{
    public class ActorController : Controller
    {
        private readonly AppDbContext _context;
        public ActorController(AppDbContext dbContext)
        {
            _context = dbContext;
        }
        public IActionResult AllActors()
        {
            var actors = _context.Actors.ToList();
            return View(actors);
        }
    }
}
