﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Demo.Migrations
{
    public partial class secondMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Actors_Actors_ActorId",
                table: "Movies_Actors");

            migrationBuilder.DropForeignKey(
                name: "FK_Movies_Actors_Movies_MovieId",
                table: "Movies_Actors");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Movies_Actors",
                table: "Movies_Actors");

            migrationBuilder.RenameTable(
                name: "Movies_Actors",
                newName: "Movie_Actors");

            migrationBuilder.RenameIndex(
                name: "IX_Movies_Actors_ActorId",
                table: "Movie_Actors",
                newName: "IX_Movie_Actors_ActorId");

            migrationBuilder.AddColumn<int>(
                name: "MoveiCategory",
                table: "Movies",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Movie_Actors",
                table: "Movie_Actors",
                columns: new[] { "MovieId", "ActorId" });

            migrationBuilder.AddForeignKey(
                name: "FK_Movie_Actors_Actors_ActorId",
                table: "Movie_Actors",
                column: "ActorId",
                principalTable: "Actors",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Movie_Actors_Movies_MovieId",
                table: "Movie_Actors",
                column: "MovieId",
                principalTable: "Movies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Movie_Actors_Actors_ActorId",
                table: "Movie_Actors");

            migrationBuilder.DropForeignKey(
                name: "FK_Movie_Actors_Movies_MovieId",
                table: "Movie_Actors");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Movie_Actors",
                table: "Movie_Actors");

            migrationBuilder.DropColumn(
                name: "MoveiCategory",
                table: "Movies");

            migrationBuilder.RenameTable(
                name: "Movie_Actors",
                newName: "Movies_Actors");

            migrationBuilder.RenameIndex(
                name: "IX_Movie_Actors_ActorId",
                table: "Movies_Actors",
                newName: "IX_Movies_Actors_ActorId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Movies_Actors",
                table: "Movies_Actors",
                columns: new[] { "MovieId", "ActorId" });

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Actors_Actors_ActorId",
                table: "Movies_Actors",
                column: "ActorId",
                principalTable: "Actors",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Movies_Actors_Movies_MovieId",
                table: "Movies_Actors",
                column: "MovieId",
                principalTable: "Movies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
